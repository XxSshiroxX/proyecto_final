enum MenuState { home, favourite, profile }
